#include<stdio.h>
#include<stdlib.h>
#include"/media/sumanth/Secondary/Toy DB using B-Tree/headers/btree.h"




// void node_init(struct node *temp, int leaf, struct bTree *bt) {
// 	temp->is_leaf = leaf;
//     temp->n = 0;
//     temp->pos = bTree->next_pos;
//     bt->next_pos++;
//     int i;
//     temp->
//     // for(i = 0; i < 2*bt->mindegree; i++) {
//         // temp->children[i] = -1;
//     // }

// }

int main(int argc, char const *argv[])
{
	/* code */
	return 0;
}