#include<stdio.h>
#include<string.h>
int main() 
{
	char str[100];
	char c;
	int i;
	char copy[100];
	char *initial;
	 i = 0;

	while((c = getchar())!='\n') {
		str[i++] = c;
	}
	str[i]='\0';
	printf("%s\n", str) ;

	initial = strtok(str, "(,)");
initial = strtok(NULL, "(,)");

	printf("%s",initial);
	printf("string after tokenizing first  %s", str);
	while(initial != NULL){
	
	initial = strtok(NULL, "(,)");
	printf("\n%s",initial);

	}
}