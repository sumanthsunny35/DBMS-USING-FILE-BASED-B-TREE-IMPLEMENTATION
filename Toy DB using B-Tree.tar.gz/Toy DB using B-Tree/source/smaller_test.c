#include<stdio.h>
#include<stdlib.h>

#define file_name "my.bin"

struct node {
	int num;
	char *name;
	char gen;
};

struct node *create_node(int num, char *name, char gen)
{
	struct node *temp = (struct node *) malloc(sizeof(struct node));

	temp->name = name;
	temp->num = num;
	temp->gen = gen;

	return temp;
}

void write_file(struct node *p, int pos)
{
	FILE *fp = fopen(file_name, "w");
	if(fp == NULL) {
		printf("failed to open file\n");
		return;
	}
	fseek(fp, pos * sizeof(struct node), 0);
	fwrite(p, sizeof(struct node), 1, fp);
	// if(fwrite != 0)  
 //        printf("contents to file written successfully !\n"); 
 //    else 
 //        printf("error writing file !\n"); 
	fclose(fp);
}

void read_file(struct node *p, int pos)
{
	FILE *fp =  fopen(file_name, "r");
	if(fp == NULL) {
		printf("failed to open file\n");
		return;
	}
	fseek(fp, pos * sizeof(struct node), 0);
	fread(p, sizeof(struct node), 1, fp);
	// printf("file read successfully\n");	
	fclose(fp);
}

int main()
{
	int num = 10;
	char gen = 'F';
	char *name = (char *) malloc(20 * sizeof(char));
	
	scanf("%s", name);
	struct node *temp = create_node(num, name, gen);
	write_file(temp, 0);
	struct node p;
	read_file(&p, 0);
	printf("name of the student : %s\n",p.students[0].name);
	printf("%s\n", file_name);
	return 0;
}
