#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"/media/sumanth/Secondary/Toy DB using B-Tree/headers/btree.h"

#define ALLOC(x) (x *)malloc(sizeof(x));

struct node * create_node(int leaf, struct bTree *bt) {
	struct node *newnode = NULL;
	newnode = (struct node *)malloc(sizeof(struct node));
	newnode->key_count = 0;
	newnode->is_leaf = leaf;
	newnode->location_in_disk = bt->next_pos;
	bt->next_pos++;
	int t = bt->min_degree;
	newnode->students = (struct student *)malloc(((2 * t)-1) * sizeof(struct student));
	newnode->children = (int *)malloc((2 * t) * sizeof(int));
	int i;
	for (i = 0; i < 2 * t; ++i) {
		newnode->children[i] = -1;
	}
	return newnode;
}

struct bTree * intialize_tree(int t, int mode) {
	struct bTree *bt = NULL;
	bt = (struct bTree *)malloc(sizeof(struct bTree));
	if (mode == 0) {
			bt->next_pos = 0;
			bt->min_degree = t;
			bt->root = 0;
			bt->node_count = 0;
			return bt;
	}	

	/*code to read btree head node from meta.dat file */
	return bt;
} 



void read_file(struct bTree *bt, struct node *p, int pos) 
{
	FILE *fp = NULL;
	fp = fopen(file_name, "r+");
	
	if(fp == NULL) {
		printf("failed to open file\n");
		return;
	}
	
	fseek(fp, pos * sizeof(struct node), 0);
    fread(p, sizeof(struct node), 1, fp);

    // printf("content is successfully read\n");
    // printf("name %s\n", p->students[0].name);
    
    fclose(fp);
}

void write_file(struct bTree * ptr_tree,struct node* p, int pos, int mod) {// pos = -1; use next_pos {
    if(pos == -1) {
        pos = ptr_tree->next_pos++;
    }
 	FILE *fp = NULL;
 	if(mod == 0) {
 		fp = fopen(file_name, "w");
 	}
 	else {
 		fp = fopen(file_name, "r+");
 	}
 	if(fp == NULL) {
		printf("failed to open file\n");
		return;
	}
	printf("node is being stored at %ld\n", pos * sizeof(struct node));
 	fseek(fp, pos * sizeof(struct node), 0);
	fwrite(p, sizeof(struct node), 1, fp);
	// if(fwrite != 0)  
 //        printf("contents to file written successfully !\n"); 
 //    else 
 //        printf("error writing file !\n"); 
    fclose(fp);
}

void split_child(struct bTree *tree, struct node *x, int i, struct node *y) {
	printf("split_child \n");
    struct node *z = create_node(y->is_leaf, tree);
    int t = tree->min_degree - 1;
    z->key_count = t - 1;
    
    int j;
    for(j = 0; j < t-1; j++) {
        z->students[j] = y->students[j+t];
    }
    if(!y->is_leaf) {
        for(j = 0; j < t; j++) {
            z->children[j] = y->children[j+t];
        }
    }
    
    y->key_count = t - 1;
    for(j = x->key_count; j >= i+1; j--) {
        x->children[j+1] = x->children[j];
    }
    x->children[i+1] = z->location_in_disk;

    for(j = x->key_count-1; j >= i; j--) {
        x->students[j+1] = x->students[j];
    }

    x->students[i] = y->students[t - 1];
    
    x->key_count++;
    
    
    write_file(tree, x, x->location_in_disk, 1);
    write_file(tree, y, y->location_in_disk, 1);
    write_file(tree, z, z->location_in_disk, 1);
    free(z);

}
void insert_non_full(struct bTree *tree,struct node *node, struct student *record) {
	
	int i = (node->key_count)-1; 	
	if(node->is_leaf) {
        
        while(i >=0 && (strcmp(node->students[i].enrollment_no, record->enrollment_no) < 0)) {
            node->students[i+1] = node->students[i];
            i--;
        }
        node->students[i+1] = *record;
        node->key_count++;
        write_file(tree, node, node->location_in_disk, 1);  
    }
    else {
        while( i >= 0 && (strcmp(node->students[i].enrollment_no, record->enrollment_no) < 0)) {
            i--;
        }
        struct node *c_i = ALLOC(struct node);
        
        read_file(tree, c_i, node->children[i+1]);
        
        if(c_i->key_count == ((2 * tree->min_degree) - 1)) {
            split_child(tree, node, i + 1, c_i);
            
            if((strcmp(node->students[i + 1].enrollment_no, record->enrollment_no) > 0)) {
                i++;
            }
        }
        read_file(tree, c_i, node->children[i+1]);
        insert_non_full(tree, c_i, record);
        free(c_i);
    }
    
}

void insert(struct bTree* tree, struct student *record)
{
	if(!(tree->next_pos)) {
        struct node *newnode = create_node(1, tree);
        newnode->students[0] = *record;
        newnode->key_count++;
        tree->root = newnode->location_in_disk;
        write_file(tree, newnode, newnode->location_in_disk, 0);
        printf("inserted the node\n");
        free(newnode);
        return;
    }
    else {
    	struct node *root = ALLOC(struct node);
    	read_file(tree, root, tree->root);
    	if(root->key_count == (2 * tree->min_degree) - 1) {
    		struct node *newroot = create_node(0, tree);
    		newroot->children[0] = tree->root;
    		split_child(tree, newroot, 0, root);
    		int i = 0;
            if (strcmp(newroot->students[0].enrollment_no, record->enrollment_no) > 0) {
                i++;
            }
            
            struct node *c_i = ALLOC(struct node);
            read_file(tree, c_i, newroot->children[i]);
            insert_non_full(tree, c_i, record);
            
            tree->root = newroot->location_in_disk;
            
            write_file(tree, root, root->location_in_disk, 1);
            
            free(newroot);

             printf("inserted the node\n");
    	}
    	else {
            
            insert_non_full(tree, root, record);
             printf("inserted the node\n");
        }
        free(root);
    }

}

struct student * search_recursive(struct bTree *tree, char *ar, struct node *root)
{
	int i = 0;
	while(i < root->key_count && (strcmp(ar, root->students[i].enrollment_no) < 0)) {
		i++;
	}

	if(i < root->key_count && (strcmp(ar, root->students[i].enrollment_no) == 0))
        return &root->students[i];
    
    
    else if(root->is_leaf) {
        return NULL;
    }
    else {
        struct node *c_i = ALLOC(struct node);
        read_file(tree, c_i, root->children[i]);
        return search_recursive(tree, ar, c_i);
    }
}

struct student * search(struct bTree *tree, char *key)
{
	struct node *root = ALLOC(struct node);
	read_file(tree, root, tree->root);

	return search_recursive(tree, key, root);
}


struct student * intialize_student()
{
	struct student *newnode = NULL;
	newnode = (struct student *) malloc(sizeof(struct student));
	newnode->name = (char *) malloc(100 * sizeof(char));
	newnode->enrollment_no = (char *) malloc(100 * sizeof(char));
	printf("read enrollment_no\n");
	scanf("%s", newnode->enrollment_no);
	printf("read name\n");
	scanf("%s", newnode->name);

	return newnode;	
}


int main()
{
	struct bTree *bt = NULL;
	int t;
	printf("read t\n");
	scanf("%d", &t);	
	bt = intialize_tree(t, 0);
	
	struct student *temp = NULL;
	int i = 0;
	while(i++ < 3) {
		temp = intialize_student();
		insert(bt, temp);
		temp = NULL;
	}
	char *key;
	while(1) {
		printf("enter search name");
		key = (char *)malloc(100 * sizeof(char));
		scanf("%s", key);
		struct student *tmp = search(bt, key);
		if(tmp == NULL) {
			printf("NULL\n");
		}
		else {
			printf("%s is the name of number %s \n", tmp->name, tmp->enrollment_no);
		}
		scanf("%d", &i);
		if(i == 0) break;
	}
	
	return 0;
}