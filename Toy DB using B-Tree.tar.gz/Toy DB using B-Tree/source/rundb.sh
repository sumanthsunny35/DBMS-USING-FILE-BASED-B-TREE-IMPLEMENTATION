#!/bin/bash

gcc -o a btree_test.c
./a

