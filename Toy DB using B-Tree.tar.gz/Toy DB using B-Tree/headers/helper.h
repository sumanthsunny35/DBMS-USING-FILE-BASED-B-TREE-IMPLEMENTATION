#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "node.h"
#include "btree.h"



void write_file(Btree* ptr_tree, Node* p, int pos); 
void read_file(Btree* ptr_tree, Node* p, int pos);